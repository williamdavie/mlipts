__hpcs__ = ['archer2','custom']
__MDcodes__ = ['lammps']
__QMcodes__ = ['vasp']
__diffmethods__ = ['emd']